- Phase 1 -- Python Mastery
	- OOP & Data Structures
		- Complete Helsinki MOOC
		- Corey Schafer OOP Playlist
			- (Classes, inheritance, dunder methods, dataclasses. Lists, dicts, sets, 
			  deques. Algorithmic complexity (Big-O). Recursion. Generators and   
			  iterators.)  
	- Scientific Python
		- NumPy (arrs, broadcasting, vectorised ops), Pandas (DataFrames, groupby, merge, apply), Matplotlib & Seaborn (Line, scatter, heatmap)
		- Python for Data Analysis: Pandas & NumPy(Coursera)
		- Numpy Official Tutorials
		- Kaggle Pandas Micro-course
- Phase 2 -- ML Foundations
	- Classical ML
		- ISLR https://www.statlearning.com/
		-
	- Deep Learning & PyTorch
		- https://course.fast.ai/
		- https://docs.pytorch.org/tutorials/beginner/basics/intro.html
	- Math needed
		- Linear algebra: matrix multiply, eigendecomposition, SVD. Calculus: 
		  chain rule, partial derivatives, Jacobians. Probability: Bayes' theorem,  
		   distributions, KL divergence, entropy. Statistics: hypothesis testing,   
		  confidence intervals, p-values.  
- Phase 3 -- LLMs & Transformers
	- Transformer Architecture
		- HuggingFace NLP Course https://huggingface.co/learn/nlp-course
			- Attention mechanism (Q, K, V). Multi-head attention. Positional 
			  encodings. Layer norm vs batch norm. Feed-forward sublayers. Encoder vs   
			  decoder vs encoder-decoder. Tokenisation (BPE). Scaling laws.   
			  Pre-training vs fine-tuning vs RLHF.  
		- Attention is all you need https://arxiv.org/abs/1706.03762
	- Fine-tuning & evaluation
		- LoRA, QLoRA (parameter-efficient fine-tuning). Prompt engineering & 
		  few-shot learning. RLHF (reward models, PPO). LLM evaluation: MMLU,   
		  benchmarks, evals design. Hallucination and calibration.  
		- https://huggingface.co/docs/peft
		- https://arxiv.org/abs/2203.02155
- Phase 4 -- AI Safety Core
	- Safety concepts & theory
		- https://alignment.anthropic.com/
		- https://aisafetyfundamentals.com/alignment/
		- https://www.alignmentforum.org/
	- Mechanistic Interpretability
		- Circuits hypothesis. Superposition & features. Sparse autoencoders 
		  (SAEs). Activation patching & causal scrubbing. Logit lens.   
		  Attribution graphs. Reading: Anthropic's circuits work and open-source   
		  circuit tracing.  
		- https://transformer-circuits.pub/
		- https://www.anthropic.com/research/open-source-circuit-tracing
		- A Walkthrough of A Mathematical Framework for Transformer Circuits: https://www.youtube.com/watch?v=KV5gbOmHbjU
	- Adversarial robustness & red-teaming
		- https://arxiv.org/abs/2307.15043
		- https://arxiv.org/abs/2411.07494
- Phase 5 -- Research skills
	- Paper Replication
		- https://paperswithcode.com/
		- https://colab.research.google.com/
	- Infrastructure & tooling
		- https://missing.csail.mit.edu/
		- https://docs.wandb.ai/quickstart
	- How to read papers fast
		- Andrew Ng: How to read papers https://www.youtube.com/watch?v=733m6qBH-jI
-
